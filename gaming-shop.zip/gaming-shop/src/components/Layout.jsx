import { Outlet } from 'react-router-dom'
import Navbar from './Navbar.jsx'
import Toasts from './Toasts.jsx'
import ScrollToTop from './ScrollToTop.jsx'

export default function Layout() {
  return (
    <div className="layout">
      <ScrollToTop />
      <Navbar />

      <main className="layout__content">
        <Outlet />
      </main>

      <footer className="footer">
        "ООО" тмыв денег
        (всё честно)
      </footer>

      <Toasts />
    </div>
  )
}
